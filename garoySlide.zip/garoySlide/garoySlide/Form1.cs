﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace garoySlide
{
    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection("Server=192.168.166.120\\sqlexpress; Initial Catalog=basa39; User Id=basa39; Password=basa39");
        public Form1()
        {
            InitializeComponent();
        }
        public string Auth(string s,string s1)
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT id from Users where Login=@login and Password=@pass", conn);
            cmd.Parameters.Add("login",SqlDbType.NVarChar).Value = s;
            cmd.Parameters.Add("pass", SqlDbType.NVarChar).Value = s1;
            int? a = (int?)cmd.ExecuteScalar();
            conn.Close();
            return a.ToString();
        }
        public void button1_Click(object sender, EventArgs e)
        {
            Auth(textBox1.Text,textBox2.Text);
        }
    }
}
