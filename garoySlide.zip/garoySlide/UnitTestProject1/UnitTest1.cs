﻿using garoySlide;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        Form1 form = new Form1();
        [TestMethod]
        public void TestMethod1()
        {
            string a = "admin";
            string b = "adminGG";
            string answer = "0";
            string result = form.Auth(a, b);

            Assert.AreEqual(answer, result);
        }
        [TestMethod]
        public void TestMethod2()
        {
            string a = "admin";
            string b = "admin";
            string answer = "0";
            string result = form.Auth(a, b);

            Assert.AreEqual(answer, result);
        }
    }
}
