﻿namespace Elevator
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.b11 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.b22 = new System.Windows.Forms.Button();
            this.b21 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.b32 = new System.Windows.Forms.Button();
            this.b31 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.b42 = new System.Windows.Forms.Button();
            this.b41 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.b52 = new System.Windows.Forms.Button();
            this.b51 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.b62 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.roundBtn6 = new Elevator.RoundBtn();
            this.roundBtn5 = new Elevator.RoundBtn();
            this.roundBtn4 = new Elevator.RoundBtn();
            this.roundBtn3 = new Elevator.RoundBtn();
            this.roundBtn2 = new Elevator.RoundBtn();
            this.roundBtn1 = new Elevator.RoundBtn();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.b11);
            this.panel1.Controls.Add(this.button18);
            this.panel1.Controls.Add(this.b22);
            this.panel1.Controls.Add(this.b21);
            this.panel1.Controls.Add(this.button15);
            this.panel1.Controls.Add(this.b32);
            this.panel1.Controls.Add(this.b31);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.b42);
            this.panel1.Controls.Add(this.b41);
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.b52);
            this.panel1.Controls.Add(this.b51);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.b62);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 426);
            this.panel1.TabIndex = 0;
            // 
            // b11
            // 
            this.b11.Location = new System.Drawing.Point(126, 356);
            this.b11.Name = "b11";
            this.b11.Size = new System.Drawing.Size(30, 23);
            this.b11.TabIndex = 24;
            this.b11.Text = "↑";
            this.b11.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(20, 356);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(75, 37);
            this.button18.TabIndex = 23;
            this.button18.Text = "1";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // b22
            // 
            this.b22.Location = new System.Drawing.Point(126, 317);
            this.b22.Name = "b22";
            this.b22.Size = new System.Drawing.Size(30, 23);
            this.b22.TabIndex = 22;
            this.b22.Text = "↓";
            this.b22.UseVisualStyleBackColor = true;
            // 
            // b21
            // 
            this.b21.Location = new System.Drawing.Point(126, 292);
            this.b21.Name = "b21";
            this.b21.Size = new System.Drawing.Size(30, 23);
            this.b21.TabIndex = 21;
            this.b21.Text = "↑";
            this.b21.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(20, 292);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(75, 37);
            this.button15.TabIndex = 20;
            this.button15.Text = "2";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // b32
            // 
            this.b32.Location = new System.Drawing.Point(126, 248);
            this.b32.Name = "b32";
            this.b32.Size = new System.Drawing.Size(30, 23);
            this.b32.TabIndex = 19;
            this.b32.Text = "↓";
            this.b32.UseVisualStyleBackColor = true;
            // 
            // b31
            // 
            this.b31.Location = new System.Drawing.Point(126, 223);
            this.b31.Name = "b31";
            this.b31.Size = new System.Drawing.Size(30, 23);
            this.b31.TabIndex = 18;
            this.b31.Text = "↑";
            this.b31.UseVisualStyleBackColor = true;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(20, 223);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 37);
            this.button12.TabIndex = 17;
            this.button12.Text = "3";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // b42
            // 
            this.b42.Location = new System.Drawing.Point(126, 182);
            this.b42.Name = "b42";
            this.b42.Size = new System.Drawing.Size(30, 23);
            this.b42.TabIndex = 16;
            this.b42.Text = "↓";
            this.b42.UseVisualStyleBackColor = true;
            // 
            // b41
            // 
            this.b41.Location = new System.Drawing.Point(126, 157);
            this.b41.Name = "b41";
            this.b41.Size = new System.Drawing.Size(30, 23);
            this.b41.TabIndex = 15;
            this.b41.Text = "↑";
            this.b41.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(20, 157);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 37);
            this.button7.TabIndex = 14;
            this.button7.Text = "4";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // b52
            // 
            this.b52.Location = new System.Drawing.Point(126, 120);
            this.b52.Name = "b52";
            this.b52.Size = new System.Drawing.Size(30, 23);
            this.b52.TabIndex = 13;
            this.b52.Text = "↓";
            this.b52.UseVisualStyleBackColor = true;
            // 
            // b51
            // 
            this.b51.Location = new System.Drawing.Point(126, 95);
            this.b51.Name = "b51";
            this.b51.Size = new System.Drawing.Size(30, 23);
            this.b51.TabIndex = 12;
            this.b51.Text = "↑";
            this.b51.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(20, 95);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 37);
            this.button4.TabIndex = 11;
            this.button4.Text = "5";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // b62
            // 
            this.b62.Location = new System.Drawing.Point(126, 41);
            this.b62.Name = "b62";
            this.b62.Size = new System.Drawing.Size(30, 23);
            this.b62.TabIndex = 9;
            this.b62.Text = "↓";
            this.b62.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(20, 27);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 37);
            this.button2.TabIndex = 8;
            this.button2.Text = "6";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.roundBtn6);
            this.panel2.Controls.Add(this.roundBtn5);
            this.panel2.Controls.Add(this.roundBtn4);
            this.panel2.Controls.Add(this.roundBtn3);
            this.panel2.Controls.Add(this.roundBtn2);
            this.panel2.Controls.Add(this.roundBtn1);
            this.panel2.Location = new System.Drawing.Point(528, 33);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(196, 365);
            this.panel2.TabIndex = 1;
            // 
            // roundBtn6
            // 
            this.roundBtn6.Location = new System.Drawing.Point(109, 74);
            this.roundBtn6.Name = "roundBtn6";
            this.roundBtn6.Size = new System.Drawing.Size(50, 45);
            this.roundBtn6.TabIndex = 5;
            this.roundBtn6.Text = "6";
            this.roundBtn6.UseVisualStyleBackColor = true;
            // 
            // roundBtn5
            // 
            this.roundBtn5.Location = new System.Drawing.Point(22, 74);
            this.roundBtn5.Name = "roundBtn5";
            this.roundBtn5.Size = new System.Drawing.Size(50, 45);
            this.roundBtn5.TabIndex = 4;
            this.roundBtn5.Text = "5";
            this.roundBtn5.UseVisualStyleBackColor = true;
            // 
            // roundBtn4
            // 
            this.roundBtn4.Location = new System.Drawing.Point(109, 139);
            this.roundBtn4.Name = "roundBtn4";
            this.roundBtn4.Size = new System.Drawing.Size(50, 45);
            this.roundBtn4.TabIndex = 3;
            this.roundBtn4.Text = "4";
            this.roundBtn4.UseVisualStyleBackColor = true;
            // 
            // roundBtn3
            // 
            this.roundBtn3.Location = new System.Drawing.Point(22, 139);
            this.roundBtn3.Name = "roundBtn3";
            this.roundBtn3.Size = new System.Drawing.Size(50, 45);
            this.roundBtn3.TabIndex = 2;
            this.roundBtn3.Text = "3";
            this.roundBtn3.UseVisualStyleBackColor = true;
            // 
            // roundBtn2
            // 
            this.roundBtn2.Location = new System.Drawing.Point(109, 198);
            this.roundBtn2.Name = "roundBtn2";
            this.roundBtn2.Size = new System.Drawing.Size(50, 45);
            this.roundBtn2.TabIndex = 1;
            this.roundBtn2.Text = "2";
            this.roundBtn2.UseVisualStyleBackColor = true;
            // 
            // roundBtn1
            // 
            this.roundBtn1.Location = new System.Drawing.Point(22, 198);
            this.roundBtn1.Name = "roundBtn1";
            this.roundBtn1.Size = new System.Drawing.Size(50, 45);
            this.roundBtn1.TabIndex = 0;
            this.roundBtn1.Text = "1";
            this.roundBtn1.UseVisualStyleBackColor = true;
            this.roundBtn1.Click += new System.EventHandler(this.roundBtn1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Elevator.Properties.Resources.close;
            this.pictureBox1.Location = new System.Drawing.Point(218, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(304, 307);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button b11;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button b22;
        private System.Windows.Forms.Button b21;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button b32;
        private System.Windows.Forms.Button b31;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button b42;
        private System.Windows.Forms.Button b41;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button b52;
        private System.Windows.Forms.Button b51;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button b62;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel2;
        private RoundBtn roundBtn1;
        private RoundBtn roundBtn6;
        private RoundBtn roundBtn5;
        private RoundBtn roundBtn4;
        private RoundBtn roundBtn3;
        private RoundBtn roundBtn2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

