﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Elevator
{
    public partial class Form1 : Form
    {
        int direction = 0;
        int nextLevel = 0;
        int thisLevel = 1;
        List<int[]> changes = new List<int[]>();

        public Form1()
        {
            InitializeComponent();

            foreach (Button button in panel1.Controls)
            {
                if (button.Name.Length == 3)
                {
                    button.Click += b67_Click;
                }
            }

            roundBtn2.Click += roundBtn1_Click;
            roundBtn3.Click += roundBtn1_Click;
            roundBtn4.Click += roundBtn1_Click;
            roundBtn5.Click += roundBtn1_Click;
            roundBtn6.Click += roundBtn1_Click;

            showLevel();
            controlChanges();
        }

        private void roundBtn1_Click(object sender, EventArgs e)
        {
            int targetLevel = Convert.ToInt32((sender as RoundBtn).Text);

            if (targetLevel == thisLevel)
            {
                MessageBox.Show("Вы уже на этом этаже");
                return;
            }
            int dir = (targetLevel > thisLevel) ? 1 : 0;
            int[] a = { targetLevel, dir };
            if (!changes.Any(c => c[0] == targetLevel && c[1] == dir))
            {
                changes.Add(a);
            }
        }

        private void showLevel()
        {
            foreach (Button c in panel1.Controls)
            {
                if (c.Text == $"{thisLevel}")
                {
                    c.BackColor = Color.Red;
                }
                else
                {
                    c.BackColor = SystemColors.Control;
                }
            }
        }

        private async void controlChanges()
        {
            while (true)
            {
                await Task.Delay(1000);
                if (changes.Count > 0)
                {
                    await changeLevel();
                }
            }
        }

        private async Task changeLevel()
        {
            while (changes.Count > 0)
            {
                selectNextLevel();
                if (nextLevel == 0) break;
                int step = (nextLevel > thisLevel) ? 1 : -1;
                while (thisLevel != nextLevel)
                {
                    thisLevel += step;
                    showLevel();
                    if (shouldStopAtFloor(thisLevel, direction))
                    {
                        await Task.Delay(1000);
                        removeStop(thisLevel, direction);
                    }

                    await Task.Delay(500);
                }
                if(nextLevel == 2)
                {
                    pictureBox1.Image = Properties.Resources.lamba;
                }
                else if(nextLevel==3)
                {
                    pictureBox1.Image = Properties.Resources.Nekit;
                }
                else if(nextLevel == 6)
                {
                    pictureBox1.Image = Properties.Resources.six;
                }
                else if(nextLevel == 5)
                {
                    pictureBox1.Image = Properties.Resources.erdem;
                }
                else if (nextLevel == 1)
                {
                    pictureBox1.Image = Properties.Resources.one;
                }
                else
                {
                    pictureBox1.Image = Properties.Resources.meme;
                }
                await Task.Delay(1000);
                removeStop(thisLevel, direction);
            }
            direction = 0;
        }

        private bool shouldStopAtFloor(int floor, int currentDirection)
        {
            return changes.Any(c =>
                c[0] == floor &&
                (c[1] == currentDirection || c[1] == 2));
        }

        private void removeStop(int floor, int dir)
        {
            changes.RemoveAll(c => c[0] == floor && (c[1] == dir || c[1] == 2));
        }

        private void b67_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            int floor = Convert.ToInt32(btn.Name[1]) - 48;

            int[] a = new int[2];

            if (btn.Text == "↓")
            {
                a[0] = floor;
                a[1] = 0;
            }
            else if (btn.Text == "↑")
            {
                a[0] = floor;
                a[1] = 1;
            }
            else
            {
                a[0] = floor;
                a[1] = 2; 
            }
            if (!changes.Any(c => c[0] == a[0] && c[1] == a[1]))
            {
                changes.Add(a);
            }
        }

        private void selectNextLevel()
        {
            if (changes.Count == 0)
            {
                nextLevel = 0;
                return;
            }
            pictureBox1.Image = Properties.Resources.close;
            if (direction == 0)
            {
                int closest = changes[0][0];
                int minDistance = Math.Abs(changes[0][0] - thisLevel);

                foreach (var call in changes)
                {
                    int distance = Math.Abs(call[0] - thisLevel);
                    if (distance < minDistance)
                    {
                        minDistance = distance;
                        closest = call[0];
                    }
                }

                nextLevel = closest;
                direction = (nextLevel > thisLevel) ? 1 : 0;
                return;
            }
            var callsInDirection = changes.Where(c =>
                (direction == 1 && c[0] > thisLevel && (c[1] == direction || c[1] == 2)) ||
                (direction == 0 && c[0] < thisLevel && (c[1] == direction || c[1] == 2))).ToList();

            if (callsInDirection.Count > 0)
            {
                if (direction == 1)
                {
                    nextLevel = callsInDirection.Min(c => c[0]);
                }
                else
                {
                    nextLevel = callsInDirection.Max(c => c[0]);
                }
            }
            else
            {
                direction = 1 - direction;
                if (direction == 1)
                {
                    nextLevel = changes.Max(c => c[0]);
                }
                else
                {
                    nextLevel = changes.Min(c => c[0]);
                }
            }
        }
    }
}
