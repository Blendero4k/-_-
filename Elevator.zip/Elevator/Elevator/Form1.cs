﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Elevator
{

    public partial class Form1 : Form
    {
        int direction = 0;
        int nextlevel = 0;
        int thisLevel = 1;
        List<int[]>changes = new List<int[]>();
        public Form1()
        {
            InitializeComponent();
            foreach (Button button in panel1.Controls)
            {
                if (button.Name.Length ==3)
                {
                    button.Click += b67_Click;
                }
            }
            roundBtn2.Click += roundBtn1_Click;
            roundBtn3.Click += roundBtn1_Click;
            roundBtn4.Click += roundBtn1_Click;
            roundBtn5.Click += roundBtn1_Click;
            roundBtn6.Click += roundBtn1_Click;
            showLevel();
        }

        private void roundBtn1_Click(object sender, EventArgs e)
        {
            if((sender as RoundBtn).Text==$"{thisLevel}")
            {
                MessageBox.Show("Вы уже на этом этаже");
                return;
            }
            if(nextlevel>thisLevel)direction = 0;
            direction = 1;
            int[] a = { Convert.ToInt32((sender as RoundBtn).Text), direction };
            changes.Add(a);
            changelevel();
        }
        private void showLevel()
        {
            foreach(Button c in panel1.Controls)
            {
                if(c.Text==$"{thisLevel}")
                {
                    (c as Button).BackColor = Color.Red;
                }
                else
                {
                    (c as Button).BackColor = SystemColors.Control;
                }
            }
        }
        private async void changelevel()
        {
            do
            {
                if (thisLevel<nextlevel)
                {
                    
                    thisLevel++;
                    showLevel();
                }
                else
                {
                    thisLevel--;
                    showLevel();
                }
                await Task.Delay(500);
            }
            while (nextlevel != thisLevel);
            await Task.Delay(1000);
            direction = 0;
            selectNextLevel();
        }

        private void b67_Click(object sender, EventArgs e)
        {
            int[] a = new int[2];
            if ((sender as Button).Text== "↓")
            {
                a[0] = Convert.ToInt32((sender as Button).Name[1]);
                a[1] = 0;
            }
            else
            {
                a[0] = Convert.ToInt32((sender as Button).Name[1]);
                a[1] = 1;
            }
            changes.Add(a);
        }
        private void selectNextLevel()
        {
            if(changes.Count==0)return;
            List<int>sortedUpper = new List<int>();
            List<int> sortedLower = new List<int>();
            for (int i = 0; i < changes.Count; i++)
            {
                if (changes[i][1]==direction)
                {
                    sortedUpper.Add(changes[i][0]);
                    changes.RemoveAt(i);
                }
                else
                {
                    sortedLower.Add(changes[i][0]);
                    changes.RemoveAt(i);
                }
            }
            int maxPriority = 0;
            if (sortedUpper.Count > 0) 
            {
                maxPriority = sortedUpper[0];
            }
            for (int i = 0; i < sortedUpper.Count; i++)
            {
                if (sortedUpper[i] > maxPriority && direction == 0)
                {
                    maxPriority = sortedUpper[i];
                }
                else if(sortedUpper[i] < maxPriority && direction == 1)
                {
                    maxPriority = sortedUpper[i];
                }
            }
            if (maxPriority != 0)
            {
                nextlevel = maxPriority;
                changelevel();
                return;
            }
            for(int i = 0;i < sortedLower.Count;i++)
            {
                if (sortedLower[i] > maxPriority && direction == 0)
                {
                    maxPriority = sortedLower[i];
                }
                else if (sortedLower[i] < maxPriority && direction == 1)
                {
                    maxPriority = sortedLower[i];
                }
            }
            nextlevel = maxPriority;
            changelevel();
        }
    }
}
