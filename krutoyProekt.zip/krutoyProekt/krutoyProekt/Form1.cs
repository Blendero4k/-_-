﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace krutoyProekt
{
    public partial class Form1 : Form
    {
        PictureBox[] player = new PictureBox[3];
        int indexPlayer = 0;
        int[,] gameloc = new int[3,2];
        Random random = new Random();
        Image[] images = {Properties.Resources._1, Properties.Resources._2, Properties.Resources._3, Properties.Resources._4,Properties.Resources._5,Properties.Resources._6 };
        Panel[,] panels = new Panel[10, 10];
        int[,] snake = { {97,83 }, {94,90 }, {85,72 }, {81,11 }, {84,64 }, {92,86 }, {89,68 }, {62,44 },{ 79,37},{67,25 },{42,5},{20, 18},{74, 13},{12,3 },{12,1} };
        public Form1()
        {
            InitializeComponent();
            for (int i = 0; i < player.Length; i++)
            {
                player[i] = new PictureBox();
                player[i].Size = new Size(10, 10);
                player[i].Location = new Point(20, 20);
                gameloc[i, 0] = 9;
                gameloc[i, 1] = 9;

            }
            player[0].BackColor = Color.Red;
            player[1].BackColor = Color.Blue;
            player[2].BackColor = Color.Green;

            tableLayoutPanel2.BackgroundImageLayout = ImageLayout.Stretch;
            for(int i=0;i<panels.GetLength(0);i++)
            {
                for (int j = 0; j < panels.GetLength(1); j++)
                {
                    if (i % 2 == 0)
                    {
                        panels[i, j] = new Panel();
                        panels[i, j].Name = $"{i}{j}";
                        tableLayoutPanel2.Controls.Add(panels[i, j], j, i);
                        panels[i, j].BackColor = Color.Transparent;
                        panels[i, j].Click += Form1_Click;
                    }
                    else
                    {
                        panels[i, j] = new Panel();
                        panels[i, j].Name = $"{i}{j}";
                        panels[i, j].BackColor = Color.Transparent;
                        tableLayoutPanel2.Controls.Add(panels[i, j], panels.GetLength(1)-1-j, i);
                        panels[i, j].Click += Form1_Click;
                    }
                }
            }
            foreach (PictureBox pic in player)
            {
                panels[gameloc[0, 0], gameloc[0, 1]].Controls.Add(pic);
            }
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            MessageBox.Show((sender as Panel).Name);
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if(indexPlayer >= player.Length)
            {
                indexPlayer = 0;
            }
            int count = random.Next(5,13);
            for (int i = 0; i < count; i++)
            {
                pictureBox1.Image = images[i % 6];
                await Task.Delay(500);
            }
            step(controlRotate());
            indexPlayer++;
        }
        private async void step(int count)
        {
            if(gameloc[indexPlayer, 1] - count<0)
            {
                gameloc[indexPlayer, 0] -= 1;
                gameloc[indexPlayer, 1] += 10;
            }
            panels[gameloc[indexPlayer, 0], gameloc[indexPlayer, 1] - count].Controls.Add(player[indexPlayer]);
            gameloc[0, 1] -= count;
            int[] a = stepSnake(gameloc);
            if (a[0] == gameloc[indexPlayer, 0] && a[1] == gameloc[indexPlayer, 1]) return;
            await Task.Delay(700);
            gameloc[indexPlayer, 0] = a[0];
            gameloc[indexPlayer, 1] = a[1];
            panels[gameloc[0, 0], gameloc[0, 1]].Controls.Add(player[indexPlayer]);
        }
        private int controlRotate()
        {
            if (pictureBox1.Image == images[0]) return 1;
            else if (pictureBox1.Image == images[1]) return 2;
            else if (pictureBox1.Image == images[2]) return 3;
            else if (pictureBox1.Image == images[3]) return 4;
            else if (pictureBox1.Image == images[4]) return 5;
            else if (pictureBox1.Image == images[5]) return 6;
            else
            {
                MessageBox.Show("Ошибка");
                return 0;
            }
        }
        private int[] stepSnake(int[,] location)
        {
            int[] newloc = new int[2];
            for (int i = 0; i < snake.GetLength(0); i++)
            {
                if (location[indexPlayer,0] == snake[i,0]/10 && location[indexPlayer,1] == snake[i,0]%10)
                {
                    newloc[0] = snake[i, 1] / 10;
                    newloc[1] = snake[i, 1] % 10;
                    return newloc;
                }
                if (location[indexPlayer,0] == snake[i, 1] / 10 && location[indexPlayer,1] == snake[i, 1] % 10)
                {
                    newloc[0] = snake[i, 0] / 10;
                    newloc[1] = snake[i, 0] % 10;
                    return newloc;
                }
            }
            newloc[0] = location[indexPlayer,0];
            newloc[1] = location[indexPlayer,1];
            return newloc;
        }
    }
}
